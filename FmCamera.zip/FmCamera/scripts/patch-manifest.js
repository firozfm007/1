const fs = require('fs');
const f = 'android/app/src/main/AndroidManifest.xml';
let x = fs.readFileSync(f, 'utf8');
const perms = `
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
`;
if (!x.includes('android.permission.CAMERA')) x = x.replace('<application', perms + '\n    <application');
if (!x.includes('requestLegacyExternalStorage')) x = x.replace('<application', '<application android:requestLegacyExternalStorage="true"');
fs.writeFileSync(f, x);
console.log('Manifest patched');

Fm Camera - Copyright Firoz

APK বানানোর ধাপ (GitHub দিয়ে):
1. github.com এ নতুন repository খুলুন (নাম: fm-camera)।
2. Zip এর ভেতরের সব ফাইল/ফোল্ডার (.github সহ) repository তে Upload করুন।
3. উপরে "Actions" ট্যাবে যান -> "Build Fm Camera APK" চলবে (৫-১০ মিনিট)।
4. সবুজ টিক হলে ওই run এ ক্লিক করুন -> নিচে Artifacts থেকে "FmCamera-APK" ডাউনলোড করুন।
5. Zip খুলে app-debug.apk ফোনে ইন্সটল করুন (Unknown sources Allow দিতে হবে)।
